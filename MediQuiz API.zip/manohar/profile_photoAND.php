<?php
require("dp.php");

$response = array();

if (isset($_POST["user_id"]) && isset($_FILES["profile_photo"])) {
    $user_id = $_POST["user_id"];
    
    // Check if the file is an image
    $fileType = strtolower(pathinfo($_FILES["profile_photo"]["name"], PATHINFO_EXTENSION));
    if ($fileType !== 'jpg' && $fileType !== 'jpeg') {
        $response['status'] = 'error';
        $response['message'] = 'Only JPG/JPEG files are allowed.';
        echo json_encode($response);
        exit;
    }
    
    // Define initial count
    $count = 0;
    
    // Check if a record with the given user_id already exists
    $check_sql = "SELECT * FROM profile WHERE user_id = '$user_id'";
    $check_result = $conn->query($check_sql);

    if ($check_result && $check_result->num_rows > 0) {
        // Get the current count from the existing file name
        $existing_filename = $check_result->fetch_assoc()['profile_photo'];
        $matches = array();
        if (preg_match('/^' . preg_quote($user_id, '/') . '_(\d+)\.jpg$/', $existing_filename, $matches)) {
            $count = intval($matches[1]) + 1;
        } else {
            // If the existing filename doesn't match the expected pattern, fallback to default count
            $count = 1;
        }

        // Update the existing record
        $update_sql = "UPDATE profile SET profile_photo = '$user_id"."_{$count}.jpg' WHERE user_id = '$user_id'";
        if ($conn->query($update_sql) === TRUE) {
            // Increment count
            $count++;
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Data not updated. Error: ' . $conn->error;
            echo json_encode($response);
            exit;
        }
    }

    // Construct the new file name with count
    $fileName = "{$user_id}_{$count}.jpg";
    $destination = "uploads/" . $fileName; // Absolute path for the destination file

    // Move the uploaded file to the specified directory
    if (move_uploaded_file($_FILES["profile_photo"]["tmp_name"], $destination)) {
        if ($check_result && $check_result->num_rows > 0) {
            $response['status'] = 'success';
            $response['message'] = 'Data updated successfully.';
        } else {
            // Insert a new record
            $insert_sql = "INSERT INTO profile (user_id, profile_photo) VALUES ('$user_id', '$user_id"."_{$count}.jpg')";
            if ($conn->query($insert_sql) === TRUE) {
                $response['status'] = 'success';
                $response['message'] = 'Data inserted successfully.';
            } else {
                $response['status'] = 'error';
                $response['message'] = 'Data not inserted. Error: ' . $conn->error;
            }
        }
        $response['filename'] = $fileName;
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Failed to move the uploaded file.';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request.';
}

header('Content-Type: application/json');
echo json_encode($response);
?>
