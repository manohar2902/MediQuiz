<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Case Studies</title>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>
<body>

<div id="caseStudyContainer"></div>

<button id="loadNext">Load Next Case Study</button>

<script>
    var currentIndex = 0; // Index to keep track of the current case study

    // Function to load the next case study
    function loadNextCaseStudy() {
        $.ajax({
            url: 'get_case_study.php',
            type: 'POST',
            data: { index: currentIndex },
            dataType: 'json',
            success: function (response) {
                if (response !== null) {
                    // Append the next case study to the container
                    $('#caseStudyContainer').append(JSON.stringify(response, null, 2));
                    currentIndex++;
                } else {
                    $('#loadNext').prop('disabled', true).text('No More Case Studies');
                }
            }
        });
    }

    // Attach click event to the button
    $('#loadNext').on('click', function () {
        loadNextCaseStudy();
    });

    // Load the first case study initially
    loadNextCaseStudy();
</script>

</body>
</html>
