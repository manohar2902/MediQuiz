<?php
include 'dp.php';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize an array to store the data
$data = array();

// Fetch all data from 'questions' table
$questionsQuery = "SELECT * FROM questions";
$questionsResult = $conn->query($questionsQuery);

// Fetch all data from 'sub_questions' table
$subQuestionsQuery = "SELECT * FROM sub_questions";
$subQuestionsResult = $conn->query($subQuestionsQuery);

// If data is found in both tables
if ($questionsResult->num_rows > 0 && $subQuestionsResult->num_rows > 0) {
    // Initialize an array to store questions
    $data['questions'] = array();

    // Loop through questions
    while ($questionRow = $questionsResult->fetch_assoc()) {
        // Initialize an array to store sub-questions for each question
        $question = $questionRow;
        $question['sub_questions'] = array();

        // Loop through sub-questions
        while ($subQuestionRow = $subQuestionsResult->fetch_assoc()) {
            // If case_study_id matches with id of questions table
            if ($subQuestionRow['case_study_id'] == $questionRow['id']) {
                // Add sub-question to the respective question
                $question['sub_questions'][] = $subQuestionRow;
            }
        }

        // Reset the pointer of the sub-questions result set
        $subQuestionsResult->data_seek(0);

        // Add the question with its sub-questions to the data array
        $data['questions'][] = $question;
    }
} else {
    // If no data found in one of the tables
    $data['questions'] = array();
}

// Output the data as JSON
header('Content-Type: application/json');
echo json_encode($data);

// Close the database connection
$conn->close();
?>
