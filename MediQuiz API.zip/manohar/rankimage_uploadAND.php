<?php
require("dp.php");

$response = array();

if (isset($_POST["s_no"]) && isset($_FILES["rank_image"])) {
    $s_no = $_POST["s_no"];
    
    // Concatenate s_no with ".jpg" extension
    $fileName = $s_no . ".jpg";
    
    $tempName = $_FILES["rank_image"]["tmp_name"];
    $folder = "uploads/"; // Change the destination folder to "uploads/"
    $destination = $folder . $fileName; // Absolute path for the destination file

    // Insert the record
    $insert_sql = "INSERT INTO `rank` (`s.no`, `rank_image`) VALUES ('$s_no', '$destination')";

    if ($conn->query($insert_sql) === TRUE) {
        // Move the uploaded file to the specified directory
        if (move_uploaded_file($tempName, $destination)) {
            $response['status'] = 'success';
            $response['message'] = 'Image uploaded successfully.';
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Failed to move the uploaded file.';
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Data not inserted. Error: ' . $conn->error;
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request.';
}

header('Content-Type: application/json');
echo json_encode($response);
?>
