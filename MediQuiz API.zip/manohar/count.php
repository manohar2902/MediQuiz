<?php
include 'dp.php';

// Initialize response array
$response = array();

// Check connection
if ($conn->connect_error) {
    $response['status'] = "error";
    $response['message'] = "Connection failed: " . $conn->connect_error;
} else {
    // SQL query to count the number of rows in the 'questions' table
    $sql = "SELECT COUNT(*) AS total_rows FROM questions";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch the result as an associative array
        $row = $result->fetch_assoc();
        
        // Cast the total_rows to an integer
        $totalRows = (int)$row["total_rows"];
        
        // Add the total number of rows to the response
        $response['status'] = "success";
        $response['total_rows'] = $totalRows;
    } else {
        // No rows found in the 'questions' table
        $response['status'] = "error";
        $response['message'] = "No rows found in the 'questions' table";
    }
}

// Close connection
$conn->close();

// Send JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
