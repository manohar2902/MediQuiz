<?php
// Include database connection file
include 'dp.php';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to retrieve user answers
$sql = "SELECT * FROM user_answer";

$result = $conn->query($sql);

// Initialize an array to store user answers
$userAnswers = array();

// Check if there are results
if ($result->num_rows > 0) {
    // Fetch each row and add it to the userAnswers array
    while ($row = $result->fetch_assoc()) {
        $userAnswers[] = array(
            "user_id" => $row["user_id"],
            "case_study_id" => $row["case_study_id"],
            "user_answer_q1" => $row["user_answer_q1"],
            "user_answer_q2" => $row["user_answer_q2"],
            "user_answer_q3" => $row["user_answer_q3"],
            "user_answer_q4" => $row["user_answer_q4"],
            "Correct" => $row["Correct"],
            "Wrong" => $row["Wrong"],
        );
    }
}

// Create an associative array with the "user_answers" key
$response = ["user_answers" => $userAnswers];

// Convert the response array to JSON
$jsonData = json_encode($response, JSON_PRETTY_PRINT);

// Output the JSON data
header("Content-Type: application/json");
echo $jsonData;

// Close the database connection
$conn->close();
?>
