<?php
require_once('dp.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input data from the application
    $user_id = $_POST['user_id'];

    // Check if the required parameter is set
    if (isset($user_id)) {
        // Retrieve user answers, correct answers, case study, and questions from the user_answer table using JOIN
        $sql = "SELECT ua.user_id, ua.case_study_id, ua.question_id, ua.user_answer,
                sq.correct_answer, sq.question, sq.option_1, sq.option_2, sq.option_3, sq.option_4,
                q.Case_Study
                FROM user_answers ua
                JOIN sub_questions sq ON ua.case_study_id = sq.case_study_id AND ua.question_id = sq.question_id
                JOIN questions q ON ua.case_study_id = q.id
                WHERE ua.user_id = '$user_id'";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $unmatchedAnswersArray = array(); // New array for unmatched answers

            while ($row = $result->fetch_assoc()) {
                // Check if user answer does not match correct answer for each row
                $userAnswer = strval($row['user_answer']) !== '0' ? 'option_' . $row['user_answer'] : 'user_answer = 0'; // Modified line
            
                if ($row['user_answer'] != $row['correct_answer']) {
                    // Fetch the correct option value from the options provided
                    $correctOption = 'option_' . $row['correct_answer'];
            
                    // Add the current answer details to the unmatchedAnswersArray
                    $answerDetails = array(
                        'caseStudyID' => intval($row['case_study_id']),
                        'caseStudy' => $row['Case_Study'],
                        'questionID' => intval($row['question_id']),
                        'question' => $row['question'],
                        'matchedOption' => $row[$correctOption], // Use correct option for unmatched answers
                    );
            
                    // Add user answer only if it's not null
                    if ($userAnswer !== null && array_key_exists($userAnswer, $row)) {
                        $answerDetails['userAnswer'] = strval($row[$userAnswer]); // Convert to string explicitly
                    } else {
                        // Add user answer as "0" if it's null or not found
                        $answerDetails['userAnswer'] = "0";
                    }
            
                    $unmatchedAnswersArray[] = $answerDetails;
                }
            }

            // Return unmatched user answers array
            $response = array(
                'status' => 'success',
                'message' => 'Unmatched User Answers Fetched',
                'unmatched_answers_array' => $unmatchedAnswersArray,
            );

            // Set the Content-Type header to ensure JSON response
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT);
        } else {
            // User answers not found
            $response = array('status' => 'error', 'message' => 'User answers not found');

            // Set the Content-Type header to ensure JSON response
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT);
        }
    } else {
        // Missing parameter
        $response = array('status' => 'error', 'message' => 'Missing required parameter.');

        // Set the Content-Type header to ensure JSON response
        header('Content-Type: application/json');
        echo json_encode($response, JSON_PRETTY_PRINT);
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => 'error', 'message' => 'Invalid request method.');

    // Set the Content-Type header to ensure JSON response
    header('Content-Type: application/json');
    echo json_encode($response, JSON_PRETTY_PRINT);
}

// Close the database connection
$conn->close();
?>
