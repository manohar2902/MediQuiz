<?php
include 'dp.php';


// Set the response content type to JSON
header('Content-Type: application/json');


// Base URL for constructing full URLs
$baseUrl = "http://14.139.187.229:8081/mediquiz/"; // Replace with your actual domain and path


// Check for a successful connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize response array
$response = [];

// Check for a valid POST request with 'user_id' parameter
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];

    // Prepare and execute the SQL query
    $stmt = $conn->prepare("SELECT profile_photo FROM profile WHERE user_id = ?");
    
    // Check for errors in the prepare statement
    if (!$stmt) {
        $response["status"] = "error";
        $response["error"] = "Error in SQL query: " . $conn->error;
    } else {
        $stmt->bind_param("s", $user_id);
        
        // Execute the statement
        if ($stmt->execute()) {
            $stmt->bind_result($scan_image);
            
            // Fetch the scan image
            if ($stmt->fetch()) {
                // Construct full URL for the image
                $fullImageUrl = $baseUrl . $scan_image;
                
                // Add the full image URL to the response
                $response["status"] = "success";
                $response["data"] = ["Profile_photo" => $fullImageUrl];
            } else {
                // No image found for the given user_id
                $response["status"] = "error";
                $response["error"] = "No scan image found for the given patient ID.";
            }
        } else {
            // Error executing the statement
            $response["status"] = "error";
            $response["error"] = "Error executing SQL statement: " . $stmt->error;
        }
    }
} else {
    // Invalid request
    $response["status"] = "error";
    $response["error"] = "Invalid request. Please provide a valid 'user_id' parameter in a POST request.";
}

// Close the database connection
$conn->close();

// Send the JSON response
echo json_encode($response);
?>
