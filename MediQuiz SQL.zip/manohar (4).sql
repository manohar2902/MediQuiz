-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 04, 2024 at 10:40 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `manohar`
--

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `user_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `phone_no` varchar(20) DEFAULT NULL,
  `institution` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `profile_photo` varchar(100) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`user_id`, `name`, `password`, `email_id`, `phone_no`, `institution`, `designation`, `profile_photo`, `created_on`) VALUES
(123, 'Tamil', '1234', 'tamil@gmail.com', '123', ' KSR', 'Student', 'uploads/123_0.jpg', '2024-03-15 11:36:39'),
(1234, 'kumaran', '1234', 'asd@gmail.com', '8518751235', 'saveetha', 'Student', 'uploads/1234.jpg', '2024-04-03 05:21:43'),
(1920, 'Manohar', '9876', 'manohar@gmail.com', '9908319699', 'Saveetha', 'Student', '', '2024-04-02 04:30:36'),
(7875, 'adsfa', '123', 'adas@gmail.com', '8976543', 'saveetha', 'Student', '', '2024-04-12 10:51:57'),
(9685, 'qweq', '2381', 'manu0@gmail.com', '99083196', 'Saveetha', 'Student', '', '2024-04-12 10:40:46'),
(9876, 'somu87', '2381', 'manu10@gmail.com', '99083196', 'Saveetha', 'Student', 'uploads/9876.png', '2024-04-16 04:19:01'),
(12345, 'somu1', '1234567', 'somu1@gmail.com', '1235648', 'saveetha', 'Student', '', '2024-04-02 07:53:48'),
(51545, 'manu', '123', 'asda@gmail.com', '78956241', 'saveetha', 'Doctor', 'uploads/51545_1.jpg', '2024-04-27 07:19:20'),
(96851, 'qweqgh', '2381', 'manu10@gmail.com', '99083196', 'Saveetha', 'Student', 'uploads/96851.jpg', '2024-04-15 04:45:14'),
(121249, 'Manohar', '23812', 'manu0@gmail.com', '99083196', 'Saveetha', 'Student', '', '2024-03-14 10:23:52'),
(123412, 'asdasd', '12345', 'asda@gmail.com', '213423412', 'saveetha', 'student', 'uploads/123412.jpg', '2024-04-16 04:45:30'),
(9685132, 'qweqgw2', '2381', 'manu10@gmail.com', '99083196', 'Saveetha', 'Student', 'uploads/9685132.png', '2024-04-15 11:59:35'),
(192011238, 'Manohar34', '1234', 'somu9@gmail.com', '1234123312', 'saveetha', 'Student', 'uploads/192011238_3.jpg', '2024-03-14 04:41:47'),
(192011298, 'mmm', '1234', 'asda@gmail.com', '8975498758', 'saveetha', 'Student', 'uploads/192011298.png', '2024-07-18 05:35:46');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `Case_Study` varchar(500) DEFAULT NULL,
  `photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `Case_Study`, `photo`) VALUES
(1, 'Unilateral, hyperpigmented macular lesion with irregularly demarcated edges over left chest in the past five months and is not associated with itching.', 'http://14.139.187.229:8081/mediquiz/uploads/profile67287c73af48d.png'),
(2, '63/M presented with multiple well defined discrete to coalescent hyperpigmented plaques on the medial aspect of the thigh, with positive AFB.', 'http://14.139.187.229:8081/mediquiz/uploads/profile67287d8ddb201.png'),
(3, '19/F presented with painful nodular lesions over lower limbs for two months. Lesions were multiple and raised.', 'http://14.139.187.229:8081/mediquiz/uploads/profile67287e127009b.png'),
(4, '38/F a known diabetic presented with thickening of skin on her nape of neck. Woody, non-pitting, erythematous plaques like lesions on her nape of neck were seen.', 'http://14.139.187.229:8081/mediquiz/uploads/profile67287e75c8e7f.png'),
(5, '74/M with 2-month h/o itching all over the body and multiple fluid filled skin lesions over left forearm and thigh for the past 2 weeks. O/E multiple vesicles noted over left forearm and thigh along with pruritic marks.', 'http://14.139.187.229:8081/mediquiz/uploads/profile672883f58648f.png'),
(6, 'A 59-year-old female presented with symmetrical eruption of firm, waxy papule and plaques of 2 to 3 mm over the head and neck. Skin is thickened and edematous.', 'http://14.139.187.229:8081/mediquiz/uploads/profile6728841df189a.png'),
(7, ' A 21-year-old female presented with a 4-month long history of multiple reddish to dark brown, pruritic lesions over the chest and right wrist with gradual extension to both forearms for the past 1 month. O/E discrete erythematous to violaceous plane topped papules noted over the flexor aspect of both forearms. Koebnerization present.', 'http://14.139.187.229:8081/mediquiz/uploads/profile6728844a3fbc6.png'),
(8, 'A 26-year-old female presented asymptomatic, progressive eruptions on both cheeks of 2 years duration. Examination revealed multiple discrete skin-colored to reddish-brown papules with a lobulated surface of size ranging between 2 mm and 5 mm.', 'http://14.139.187.229:8081/mediquiz/uploads/profile6728848f62be1.png'),
(9, 'A 50-year-old male presented with shiny, skin coloured bump with raised edges of 2 cm in diameter over the nose for past 3 months.', 'http://14.139.187.229:8081/mediquiz/uploads/profile672884a63484c.png'),
(10, 'A 14-year-old girl presented with multiple hyperpigmented skin macules, generalized freckling, café au lait spots throughout the body. She also has a history of seizure disorder.', 'http://14.139.187.229:8081/mediquiz/uploads/profile672884c14200c.png'),
(11, 'A 29-year-old female with swelling on the right side of her tongue.', 'http://14.139.187.229:8081/mediquiz/uploads/profile672889b0d6877.png'),
(12, 'A two and half year-old male child with a large black color skin patch over facial region since birth.', 'http://14.139.187.229:8081/mediquiz/uploads/profile672889c8e9468.png'),
(13, 'A 52-year-old female presented with progressive growth of a pigmented nodular lesion on the right arm.', 'http://14.139.187.229:8081/mediquiz/uploads/profile672889e691f89.png'),
(14, 'A 12-year-old boy with 7-month history of isolated painless mass over left arm.', 'http://14.139.187.229:8081/mediquiz/uploads/profile67288a102461f.png'),
(15, 'A 51-year-old woman presented with a row of slowly enlarging lesions on her right scalp and forehead.', 'http://14.139.187.229:8081/mediquiz/uploads/profile67288a267b815.png'),
(16, '25-year-old man presented with round to oval patchy discoloration over upper trunk and back and extending up to lower back, along with mild itching.', 'http://14.139.187.229:8081/mediquiz/uploads/profile67288a3c5be66.png'),
(17, 'A 64-year-old male presented with 16-year history of asymptomatic to occasionally painful nodule over left scapular region.', 'http://14.139.187.229:8081/mediquiz/uploads/profile67288a562b860.png'),
(18, 'A 59-year-old female with 3-year history of a growing nodule on the left forearm, which bled with minor trauma.', 'http://14.139.187.229:8081/mediquiz/uploads/profile67288a6b6d292.png'),
(19, 'A 26-year-old male with 1-month h/o multiple hypochromic raised lesion over his hands and ears with chalky white discharge.  Ichthyotic patch with decreased sensitivity over left forearm. ', 'http://14.139.187.229:8081/mediquiz/uploads/profile67288a8563af9.png'),
(20, 'A 30-year-old women presents with nodular, solid, cutaneous mass over the neck for past 3 months of size 3cm in diameter. On gross well-circumscribed nodule seen.', 'http://14.139.187.229:8081/mediquiz/uploads/profile67288aa0c1e7f.png'),
(21, 'A 20-year-old male presented with index finger mass', 'http://14.139.187.229:8081/mediquiz/uploads/profile67288f796a240.png'),
(22, 'A 28-year-old man presented with a 3-month history of multiple skin lesions over hand, back and trunk, associated with intermittent pain on the lesions. History of multiple sexual partners present. On examination, multiple pink and white, smooth-surfaced, sessile, non-tender papules measuring 2 to 3 mm in diameter were observed.', 'http://14.139.187.229:8081/mediquiz/uploads/profile67288f8f5fa53.png'),
(23, 'A 56-year-old male with painful red plaque at the inner side of his left ankle.', 'http://14.139.187.229:8081/mediquiz/uploads/profile67288fa616844.png'),
(24, 'A 9-year-old boy with insignificant past medical history presented with a history of persistent very itchy multiple skin lesions all over the body since he was six years old and without history of remissions or exacerbations. O/E multiple well-defined scaly follicular plaques were noted on an erythematous base of varying sizes over the neck, arm, and left foot.', 'http://14.139.187.229:8081/mediquiz/uploads/profile67288fbdc6f02.png'),
(25, 'A 20-year-old male with an ulcerated lesion on the big toe.', 'http://14.139.187.229:8081/mediquiz/uploads/profile67288fcd92b9d.png');

-- --------------------------------------------------------

--
-- Table structure for table `rank`
--

CREATE TABLE `rank` (
  `s.no` int(11) NOT NULL,
  `rank_image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rank`
--

INSERT INTO `rank` (`s.no`, `rank_image`) VALUES
(1, 'uploads/1.jpg'),
(2, 'uploads/2.jpg'),
(3, 'uploads/3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `sub_questions`
--

CREATE TABLE `sub_questions` (
  `id` int(11) NOT NULL,
  `case_study_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `question` varchar(250) DEFAULT NULL,
  `option_1` varchar(100) DEFAULT NULL,
  `option_2` varchar(100) DEFAULT NULL,
  `option_3` varchar(100) DEFAULT NULL,
  `option_4` varchar(100) DEFAULT NULL,
  `correct_answer` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sub_questions`
--

INSERT INTO `sub_questions` (`id`, `case_study_id`, `question_id`, `question`, `option_1`, `option_2`, `option_3`, `option_4`, `correct_answer`) VALUES
(323, 1, 1, 'What is your likely diagnosis?', 'Becker\'s nevus', 'Compound nevus', 'Congenital melanotic nevus', 'Congenital smooth muscle hamartoma', 1),
(324, 1, 2, 'All are included in epidermal nevi EXCEPT', 'Nevus sebaceous', 'Nevus comedonicus', 'Becker\'s nevus', 'Blue nevus', 2),
(325, 1, 3, 'What are the associated forms of lesion?', 'sebaceous hyperplasia', 'hyperhidrosis', 'hypertrichosis', 'skin tags', 3),
(326, 1, 4, 'Which of the following musculoskeletal defects are associated with this lesion?', 'unilateral breast hypoplasia', 'kyphosis', 'pectus carinatum', 'hiatus hernia', 1),
(327, 2, 1, 'What is your opinion of the above mentioned case?', 'Keratotic lupus vulgaris', 'Tuberculosis verrucosa cutis', 'Pyoderma vegetans', 'Verruca vulgaris', 2),
(328, 2, 2, 'Apple jelly nodules are described in which form of cutaneous tuberculosis?', 'Scrofuloderma', 'Orificial tuberculosis', 'Papulonecrotic tuberculid', 'Lupus vulgaris', 4),
(329, 2, 3, 'Which form of cutaneous tuberculosis is associated with M. avium infection?', 'Lupus vulgaris', 'Erythema induratum', 'Lichen scrofulosorum', 'Orificial TB', 3),
(330, 2, 4, 'Which skin malignancy can arise from untreated lupus vulgaris?', 'Basal cell carcinoma', 'Squamous cell carcinoma', 'T cell lymphoma', 'Melanoma', 2),
(331, 3, 1, 'What is the type of panniculitis observed here?', 'Septal panniculitis', 'Lobular panniculitis', 'Lobular panniculitis with vasculitis', 'Septal panniculitis with vasculitis', 1),
(332, 3, 2, 'Which of the following is the most common form of panniculitis?', 'Erythema nodosum', 'Erythema induratum', 'Sclerema neonatorum', 'Factitial panniculitis', 1),
(333, 3, 3, 'Which malignancy is associated with erythema nodosum?', 'Adenocarcinoma', 'Squamous cell carcinoma', 'Hodgkin’s lymphoma', 'Melanoma', 3),
(334, 3, 4, 'What is Vilanova disease?', 'Subacute nodular migratory panniculitis', 'Subcutaneous granuloma annulare', 'Cytophagic histiocytic panniculitis', 'Pancreatic panniculitis', 1),
(335, 4, 1, 'What is your diagnosis?', 'Eosinophilic fasciitis', 'Scleredema diabeticorum', 'Localized scleroderma', 'Primary systemic amyloidosis', 2),
(336, 4, 2, 'Which skin manifestation is considered as a prognostic indicator for developing type 2 diabetes?', 'Diabetic dermopathy', 'Eruptive xanthoma', 'Acanthosis nigricans', 'Rubeosis faciei', 3),
(337, 4, 3, 'All the following systemic manifestations are associated with bullosis diabeticorum in type 1 diabetic patients EXCEPT', 'Nephropathy', 'Retinopathy', 'Peripheral neuropathy', 'Cardiomyopathy', 4),
(338, 4, 4, 'Which cutaneous manifestation arises in uncontrolled diabetes?', 'Tendinous xanthoma', 'Eruptive xanthoma', 'Tuberous xanthoma', 'Verruciform xanthoma', 2),
(339, 5, 1, 'What is your diagnosis?', 'Linear IgA disease', 'Dermatitis herpetiformis', 'Epidermolysis bullosa', 'Bullous pemphigoid', 4),
(340, 5, 2, 'Direct immunofluorescence pattern with regard to this condition?', 'IF would show granular IgA deposition at the tips of dermal papillae', 'IF would show IgG and C3 reactivity in a fishnet-like pattern', 'IF would show linear IgA reactivity along the basement membrane', 'IF would show linear IgG and C3 reactivity at the basement membrane', 4),
(341, 5, 3, 'Antigens targeted in this condition?', 'BPAG1 and BPAG2', 'Collagen VII', 'Desmoglein 1 and desmoglein 3', 'Envoplakin and periplakin', 1),
(342, 5, 4, 'Accumulation of which inflammatory infiltrates is commonly seen?', 'Eosinophils', 'Neutrophils', 'Lymphocytes', 'Mast cells', 1),
(343, 6, 1, 'What is your diagnosis?', 'Eosinophilic fasciitis', 'Scleromyxedema', 'Follicular mucinosis', 'Localized scleroderma', 2),
(344, 6, 2, 'What is morphea?', 'Edema and hypertrophies collagen bundle', 'Sclerosis limited to papillary dermis', 'Entrapped atrophic adnexal structure with loss of adipose tissue', 'Epidermal atrophy, acanthosis, atypia, loss of adnexal structures', 3),
(345, 6, 3, 'This condition is usually associated with?', 'Paraproteinemia', 'Amyloidosis', 'Sarcoidosis', 'Plasma cell dyscrasia', 1),
(346, 6, 4, 'The characteristic histopathological triad of this condition is?', 'Diffuse dermal mucin production, increased collagen, irregularly shaped fibroblast', 'Focal dermal mucin production, decreased collagen production, irregularly shaped fibroblast', 'Focal dermal mucin production, increased collagen, irregularly shaped fibroblast', 'Diffuse dermal mucin production, decreased collagen, regularly shaped fibroblast', 1),
(347, 7, 1, 'What is your diagnosis?', 'Psoriasis', 'Lichen planus', 'Kaposi sarcoma', 'Lichen nitidus', 2),
(348, 7, 2, 'Which of the following is true about cutaneous lichen planus?', 'Civatte bodies are PAS negative', 'Eosinophils are common', 'Dyskeratotic keratinocytes are frequently seen at basal layer', 'Mucosal involvement is seldom seen', 3),
(349, 7, 3, 'Which of the histological features of lichenoid drug eruption is absent in classic lichen planus?', 'Civatte bodies', 'Eosinophils', 'Hypergranulosis', 'Hyperkeratosis', 2),
(350, 7, 4, 'The virus associated with the development of this disease is?', 'HBV', 'HAV', 'HEV', 'HCV', 4),
(351, 8, 1, 'What is your diagnosis?', 'Xanthelasma', 'Syringoma', 'Sarcoidosis', 'Mastocytosis', 2),
(352, 8, 2, 'Which of the following characteristics is typical of this lesion?', 'Associated with Turner syndrome', 'May recur after excision', 'Often multiple 1-4 mm, firm, flesh-colored papule', 'Painful lesions', 3),
(353, 8, 3, 'Clear cell changes in this condition are due to?', 'Clearing artifact', 'Globulin', 'Glycogen', 'Lipids', 3),
(354, 8, 4, 'The origin of the lesion is from?', 'Apocrine sweat gland', 'Eccrine sweat gland', 'Apocrine sudoriferous gland', 'Eccrine sudoriferous gland', 2),
(355, 9, 1, 'What is your diagnosis?', 'Squamous cell carcinoma', 'Basal cell carcinoma', 'Malignant melanoma', 'Trichoblastoma', 2),
(356, 9, 2, 'All are commonest variants of this condition EXCEPT?', 'Infiltrative', 'Superficial', 'Nodular', 'Clear cell', 4),
(357, 9, 3, 'All of the following are positive stains for this condition EXCEPT?', 'p63', 'p53', 'CK20', 'CD10', 3),
(358, 9, 4, 'All of the following are good prognostic factors for local recurrence EXCEPT?', 'Nodular', 'Micronodular', 'Superficial', 'Pigmented', 2),
(359, 10, 1, 'What is your diagnosis?', 'Schwannoma', 'Desmoplastic melanoma', 'Nerve sheath myxoma', 'Neurofibroma', 4),
(360, 10, 2, 'Which one of the following IHC stains is positive for this condition?', 'CD34', 'CK5/6', 'EMA', 'HMB45', 1),
(361, 10, 3, 'How can you differentiate between desmoplastic melanoma and neurofibroma using IHC?', 'CD34', 'EMA', 'HMB45', 'MelanA', 1),
(362, 10, 4, 'How can you differentiate between schwannoma and neurofibroma using IHC?', 'CK5/6', 'p63', 'S100', 'MelanA', 3),
(363, 11, 1, 'What is your opinion of the above mentioned case?', 'Angiokeratoma corporis diffusum', 'Condyloma accuminata', 'Lymphangioma circumscriptum', 'Cystic hygroma', 3),
(364, 11, 2, 'Which of the following cells are commonly noted in these lesions?', 'Neutrophils', 'Eosinophils', 'Monocytes', 'Lymphocytes', 4),
(365, 11, 3, 'IHC marker used for the diagnosis?', 'CD35A', 'D2-40', 'FOXC2', 'CD24A', 2),
(366, 11, 4, 'Macrocystic lymphatic malformations seen in neonates are associated with which of the following syndromes?', 'Beckwith-Wiedemann syndrome', 'Fragile X syndrome', 'Meckel-Gruber syndrome', 'Noonan syndrome', 4),
(367, 12, 1, 'What is your diagnosis?', 'Becker\'s nevus', 'Nevus of Ito', 'Congenital melanotic nevus', 'Nevus sebaceous', 3),
(368, 12, 2, 'Lifetime risk of developing melanoma varies between?', '1% and 5%', '5% and 10%', '10% and 15%', '15% and 20%', 2),
(369, 12, 3, 'Overexpression of one of the following factors is associated with this condition?', 'Fibroblast growth factor', 'Epidermal growth factor', 'Hepatocyte growth factor', 'Keratinocyte growth factor', 3),
(370, 12, 4, 'All of the following features are seen in this condition except?', 'Elongation of epidermal ridges', 'Absence of dermal extension', 'Hyperkeratosis and hyperplasia', 'Lentigo-like alterations', 2),
(371, 13, 1, 'What is your diagnosis?', 'Nevoid melanoma', 'Nodular melanoma', 'Lentigo melanoma', 'Metastatic melanoma', 2),
(372, 13, 2, 'Most common associated genetic mutation of this condition?', 'BRAF', 'C-KIT', 'NRAS', 'IDH1', 3),
(373, 13, 3, 'Breslow depth is measured from the top of which layer?', 'Basal layer', 'Granular layer', 'Spinous layer', 'Papillary layer', 2),
(374, 13, 4, 'All of the following are positive stains for this condition EXCEPT?', 'MITF', 'GATA3', 'S100', 'HMB45', 2),
(375, 14, 1, 'What is your diagnosis?', 'Osteoma cutis', 'Dermoid cyst', 'Trichoblastoma', 'Pilomatricoma', 4),
(376, 14, 2, 'What is the gene mutation associated with the lesion?', 'VPS33B', 'COL2A1', 'CTNNB1', 'ATP1A3', 3),
(377, 14, 3, 'The above mentioned condition is associated with which of the following syndromes?', 'Myotonic dystrophy', 'Gardner syndrome', 'Noonan syndrome', 'Kabuki syndrome', 2),
(378, 14, 4, 'The familial inheritance of this condition is associated with mutation of?', 'FGFR3', 'UBE3A', 'HLXB9', 'PLCD1', 4),
(379, 15, 1, 'What is your diagnosis?', 'Dermatofibroma', 'Cylindroma', 'Spiradenoma', 'Trichoepithelioma', 2),
(380, 15, 2, 'What is the gene mutation associated with the lesion?', 'CYLD', 'HRAS', 'MATP', 'PTEN', 1),
(381, 15, 3, 'All of the following immunohistochemical stains would be positive in this condition EXCEPT?', 'CK7', 'CK20', 'EMA', 'CEA', 2),
(382, 15, 4, 'Which of the following constitutes Brooke-Spiegler Syndrome?', 'Trichoblastoma, Cylindroma, Spiradenoma', 'Syringoma, Trichoepithelioma, Spiradenoma', 'Cylindroma, Spiradenoma, Trichoepithelioma', 'Trichoepithelioma, Syringoma, Cylindroma', 3),
(383, 16, 1, 'What is your diagnosis?', 'Guttate psoriasis', 'Pityriasis versicolor', 'Seborrheic dermatitis', 'Granuloma annulare', 2),
(384, 16, 2, 'Which of the following dermatophytes does not have the spore form characteristics called microconidia?', 'Microsporum spp.', 'Trichophyton spp.', 'Epidermophyton spp.', 'Blastomyces spp.', 3),
(385, 16, 3, 'The infectious pathogen is located in which layer of skin?', 'S. granulosum', 'S. spinosum', 'S. corneum', 'S. basale', 3),
(386, 16, 4, 'Which one of the following causative agents is associated with Athlete\'s foot?', 'Epidermophyton', 'Malassezia furfur', 'Microsporum', 'Trichophyton', 4),
(387, 17, 1, 'What is your diagnosis?', 'Dermatologic metastatic carcinoma', 'Cellular fibrous histiocytoma', 'Dermatofibrosarcoma protuberans', 'Spindle cell melanoma', 3),
(388, 17, 2, 'Which of the following immunohistochemical stains would be diffusely positive in this condition?', 'Desmin', 'CD34', 'S100', 'MelanA', 2),
(389, 17, 3, 'Which of the following chromosomal aberrations is responsible for this condition?', 'Deletion', 'Inversion', 'Translocation', 'Duplication', 3),
(390, 17, 4, 'All are risk factors for poor prognosis for this condition EXCEPT', 'High mitotic index', 'Age less than 50 years', 'Fibrosarcomatous variant', 'Increased cellularity', 2),
(391, 18, 1, 'What is your diagnosis?', 'Amelanotic melanoma', 'Metastatic adenocarcinoma', 'Eccrine Porocarcinoma', 'Merkel cell carcinoma', 3),
(392, 18, 2, 'All of the following are positive stains EXCEPT', 'Actin', 'Keratin', 'EMA', 'CEA', 1),
(393, 18, 3, 'All of the following are good prognostic factors for this condition EXCEPT', 'Depth of invasion < 7 mm', 'Lymphovascular invasion', 'mitosis < 14/10 hpf', 'Lymph node avoidance', 2),
(394, 18, 4, 'The predominant site of the lesion is', 'Scalp', 'Trunk', 'Upper extremity', 'Lower extremity', 4),
(395, 19, 1, 'What is your diagnosis?', 'Nummular dermatitis', 'Cutaneous leishmaniasis', 'Lepromatous leprosy', 'Mycosis fungoides', 3),
(396, 19, 2, 'Lepromin test is strongly positive in?', 'Tuberculoid leprosy', 'Lepromatous leprosy', 'Borderline leprosy', 'Histiocytoid leprosy', 1),
(397, 19, 3, 'Early reaction to skin test is called?', 'Mitsuda reaction', 'Finkelstein reaction', 'Swartz reaction', 'Fernandez reaction', 4),
(398, 19, 4, 'CD4:CD8 ratio in this case is?', '1: 1', '1: 2', '2: 1', '2: 2', 2),
(399, 20, 1, 'What is your diagnosis?', 'Squamous cell carcinoma', 'Clear cell hidradenoma', 'Metastatic renal cell carcinoma', 'Eccrine cylindroma', 2),
(400, 20, 2, 'All of the following are positive stains EXCEPT?', 'p63', 'CD10', 'SMA', 'EMA', 2),
(401, 20, 3, 'The cytogenetic abnormality resulting in this condition?', 't(10;20)', 't(11;21)', 't(11;19)', 't(10;22)', 3),
(402, 20, 4, 'The origin of the lesion is from?', 'Apocrine sweat gland', 'Eccrine sweat gland', 'Apocrine sudoriferous gland', 'Eccrine sudoriferous gland', 2),
(403, 21, 1, 'What is your diagnosis?', 'Glomus tumour', 'Paraganglioma', 'Myopericytoma', 'Nodular hidradenoma', 1),
(404, 21, 2, 'Which of the following molecular aberration can be seen in this condition?', 'ETV6- NTRK3', 'EWSR1- FLI1', 'MIR143- NOTCH 1', 'SS18- SSX2', 3),
(405, 21, 3, 'Which of the following is true?', 'complete surgical resection is curative', 'metastasize occurs in 30% of cases', 'diffuse positive for CD34, CD31, ERG', 'most common location is ankle', 1),
(406, 21, 4, 'Positive for which stain?', 'SMA', 'Keratin', 'Desmin', 'CD31', 1),
(407, 22, 1, 'What is your diagnosis?', 'Verruca vulgaris', 'Pemphigus foliaceus', 'Molluscum Contagiosum', 'Epidermolysis bullosa', 3),
(408, 22, 2, 'Which of the following virus is responsible for this lesion?', 'double stranded DNA virus replicating in the cytoplasm', 'double stranded RNA virus replicating in the nucleus', 'single stranded DNA virus replicating in the cytoplasm', 'single stranded RNA virus replicating in the cytoplasm', 1),
(409, 22, 3, 'Which of the following is affected in this condition?', 'Melanocytes', 'Merkel cell', 'Koilocyes', 'Keratinocytes', 4),
(410, 22, 4, 'Which of the following is the most likely cause?', 'HPV 1', 'HPV 2', 'MCV 1', 'MCV 2', 3),
(411, 23, 1, 'What is your diagnosis?', 'Pheohyphomycosis', 'Coccidioidomycosis', 'Chromoblastomycosis', 'Botryomycosis', 3),
(412, 23, 2, 'The classical histopathological hallmark seen in this condition is', 'Kamino bodies', 'Medlar bodies', 'Dutcher bodies', 'Verocay bodies', 2),
(413, 23, 3, 'Which of the following infective species is usually associated with this condition?', 'Phialophora spp.', 'Exophiala spp.', 'Fonsecaea spp.', 'Rhinocladiella spp.', 3),
(414, 23, 4, 'Long standing disease state results in', 'Acinar cell carcinoma', 'Squamous cell carcinoma', 'Transitional cell carcinoma', 'Renal cell carcinoma', 2),
(415, 24, 1, 'What is your diagnosis?', 'Lichen planopilaris', 'Erythrokeratoderma variabilis', 'Lichen ruber acuminatus', 'Cutaneous T-cell lymphoma', 3),
(416, 24, 2, 'Most common genetic mutation associated with this condition', 'PTPN11', 'MCR1R', 'CARD14', 'GTF2H5', 3),
(417, 24, 3, 'Which of the following subtype of this condition is associated with HIV?', 'Type II', 'Type III', 'Type V', 'Type VI', 4),
(418, 24, 4, 'What is the most specific histologic finding of this condition?', 'Checkerboard hyperkeratosis pattern', 'Psoriasiform epidermal hyperplasia', 'Hyperkeratosis and perivascular lymphocytic infiltrate', 'Sparse superficial inflammation', 1),
(419, 25, 1, 'What is your diagnosis?', 'Verrucous psoriasis', 'Keratoacanthoma', 'Verrucous carcinoma', 'Carcinoma cuniculatum', 3),
(420, 25, 2, 'Most common somatic genetic mutation associated with this condition', 'GNAS', 'EGFR', 'HRAS', 'PTEN', 3),
(421, 25, 3, 'Which of the following are true about this condition?', 'Female preponderance', 'Has four variants', 'Predilection for young age', 'Most common affected site is foot', 4),
(422, 25, 4, 'What is the most specific histologic finding of this condition?', 'Exophytic and endophytic growth of bland appearing squamous epithelium with deep pushing borders', 'Exophytic verrucous growth of squamous epithelium commonly with koilocytosis change', 'Exophytic verrucous growth of squamous epithelium with high mitotic activity and necrosis', 'Well differentiated squamous neoplasm with mainly endophytic infiltrative growth', 1);

-- --------------------------------------------------------

--
-- Table structure for table `totalscore`
--

CREATE TABLE `totalscore` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_score` int(11) DEFAULT NULL,
  `total_wrong` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_answers`
--

CREATE TABLE `user_answers` (
  `id` int(11) NOT NULL,
  `user_id` int(20) NOT NULL,
  `case_study_id` int(250) DEFAULT NULL,
  `question_id` int(250) DEFAULT NULL,
  `user_answer` int(250) DEFAULT NULL,
  `Correct` int(250) NOT NULL,
  `Wrong` int(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rank`
--
ALTER TABLE `rank`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `sub_questions`
--
ALTER TABLE `sub_questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `totalscore`
--
ALTER TABLE `totalscore`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user_answers`
--
ALTER TABLE `user_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `case_study_id` (`case_study_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=192011299;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `rank`
--
ALTER TABLE `rank`
  MODIFY `s.no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sub_questions`
--
ALTER TABLE `sub_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=423;

--
-- AUTO_INCREMENT for table `totalscore`
--
ALTER TABLE `totalscore`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- AUTO_INCREMENT for table `user_answers`
--
ALTER TABLE `user_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1882;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_answers`
--
ALTER TABLE `user_answers`
  ADD CONSTRAINT `user_answers_ibfk_2` FOREIGN KEY (`case_study_id`) REFERENCES `questions` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
