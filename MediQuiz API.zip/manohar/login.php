<?php

include 'dp.php';
$bioid =$_GET['user_id'];
$password =$_GET['password'];
//$bioid = 'test@gmail.com'; 
//$_POST['bioid'];
//$password ='pass123';
//echo  $bioid. $password;   //$_POST['password'];
$loginqry = "SELECT * FROM profile WHERE user_id = '$bioid' AND password = '$password'";
//$loginqry = "SELECT * FROM users WHERE bioid = 10101 AND password ='pass123'";
$qry = mysqli_query($conn, $loginqry);
if(mysqli_num_rows($qry) > 0){
$userObj = mysqli_fetch_assoc($qry);
$response['status'] = true;
$response['message']= " Login Successfully";
$response['data'] = $userObj;
}
else{
$response['status'] = false;
$response['message']= "Login Failed";
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>