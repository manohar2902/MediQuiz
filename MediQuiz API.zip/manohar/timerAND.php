<?php
// Define the integer
$number = 3600;

// Create an array to hold the response
$response = array(
    'status' => 'success',
    'timer' => $number
);

// Convert the response array to JSON format
$json_response = json_encode($response);

// Set the appropriate header to indicate JSON content
header('Content-Type: application/json');

// Output the JSON response
echo $json_response;
?>
