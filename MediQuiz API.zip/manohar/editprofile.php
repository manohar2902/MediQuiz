<?php
require_once('dp.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the user_id is provided in the request
    if (!isset($_POST['user_id'])) {
        $response = array('status' => 'error', 'message' => 'User ID not provided.');
        echo json_encode($response);
        exit; // Terminate script execution
    }

    // Retrieve user_id from the POST request
    $user_id = $_POST['user_id'];

    // Check if the user_id already exists in the database
    $check_sql = "SELECT user_id FROM profile WHERE user_id = '$user_id'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows == 0) {
        // User does not exist
        $response = array('status' => 'error', 'message' => 'User does not exist.');
        echo json_encode($response);
        exit; // Terminate script execution
    }

    // Check if passwords match
    if ($_POST['password'] !== $_POST['re_password']) {
        $response = array('status' => 'error', 'message' => 'Passwords do not match.');
        echo json_encode($response);
        exit; // Terminate script execution
    }

    // Update user information
    $update_fields = array();
    if (!empty($_POST['name'])) {
        $update_fields[] = "name = '{$_POST['name']}'";
    }
    if (!empty($_POST['phone_no'])) {
        $update_fields[] = "phone_no = '{$_POST['phone_no']}'";
    }
    if (!empty($_POST['email_id'])) {
        $update_fields[] = "email_id = '{$_POST['email_id']}'";
    }
    if (!empty($_POST['institution'])) {
        $update_fields[] = "institution = '{$_POST['institution']}'";
    }
    if (!empty($_POST['designation'])) {
        $update_fields[] = "designation = '{$_POST['designation']}'";
    }
    if (!empty($_POST['password'])) {
        // Update password only if provided
        $update_fields[] = "password = '{$_POST['password']}'";
    }

    // Handle image upload if provided
    if (!empty($_FILES['profile_photo']['name'])) {
        $imageFileType = strtolower(pathinfo($_FILES['profile_photo']['name'], PATHINFO_EXTENSION)); // Get the file extension

        // Extract the count from the existing file name
        $existing_count = 0;
        $existing_file = "uploads/{$user_id}_{$existing_count}.{$imageFileType}";
        while (file_exists($existing_file)) {
            $existing_count++;
            $existing_file = "uploads/{$user_id}_{$existing_count}.{$imageFileType}";
        }

        // Set the target file with the incremented count
        $targetFile = "uploads/{$user_id}_{$existing_count}.{$imageFileType}";

        if (move_uploaded_file($_FILES['profile_photo']['tmp_name'], $targetFile)) {
            $update_fields[] = "profile_photo = '$targetFile'";
        } else {
            $response = array('status' => 'error', 'message' => 'Sorry, there was an error uploading your file.');
            echo json_encode($response);
            exit; // Terminate script execution
        }
    }

    // Construct the UPDATE query
    if (!empty($update_fields)) {
        $update_query = "UPDATE profile SET " . implode(", ", $update_fields) . " WHERE user_id = '$user_id'";

        if ($conn->query($update_query) === TRUE) {
            $response = array('status' => 'success', 'message' => 'User information updated successfully.');
            echo json_encode($response);
        } else {
            $response = array('status' => 'error', 'message' => 'Error updating user information: ' . $conn->error);
            echo json_encode($response);
        }
    } else {
        // No fields to update
        $response = array('status' => 'error', 'message' => 'No fields to update.');
        echo json_encode($response);
    }
} else {
    // Handle non-POST requests
    $response = array('status' => 'error', 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
