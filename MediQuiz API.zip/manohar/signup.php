<?php
// Include your database connection file
require_once('dp.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input data from the application
    $username = $_POST['user_id'];
    $name = $_POST['name'];
    $mobilenumber = $_POST['phone_no'];
    $email = $_POST['email_id'];
    $password = $_POST['password'];
    $re_password = $_POST['re_password']; // New field for re-entering password
    $institution = $_POST['institution'];
    $designation = $_POST['designation'];

    // Check if passwords match
    if ($password !== $re_password) {
        $response = array('status' => 'error', 'message' => 'Passwords do not match.');
        echo json_encode($response);
        exit(); // Exit the script to prevent further execution
    }

    // Handle image upload
    $targetDir = "uploads/"; // Directory where images will be stored
    $imageFileType = strtolower(pathinfo($_FILES["profile_photo"]["name"], PATHINFO_EXTENSION)); // Get the file extension
    $targetFile = $targetDir . $username . "." . $imageFileType; // Path to store the uploaded image with user_id as filename

    // Check if the image file is an actual image or fake image
    $check = getimagesize($_FILES["profile_photo"]["tmp_name"]);
    if($check !== false) {
        $uploadOk = 1;
    } else {
        $response = array('status' => 'error', 'message' => 'File is not an image.');
        echo json_encode($response);
        $uploadOk = 0;
    }

    // Allow only certain file formats
    $allowedExtensions = array("jpg", "jpeg", "png", "gif");
    if(!in_array($imageFileType, $allowedExtensions)) {
        $response = array('status' => 'error', 'message' => 'Sorry, only JPG, JPEG, PNG & GIF files are allowed.');
        echo json_encode($response);
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        $response = array('status' => 'error', 'message' => 'Sorry, your file was not uploaded.');
        echo json_encode($response);
    } else {
        // Check if the user already has a profile photo
        $checkPhotoQuery = "SELECT profile_photo FROM profile WHERE user_id = '$username'";
        $checkPhotoResult = $conn->query($checkPhotoQuery);
        
        if ($checkPhotoResult && $checkPhotoResult->num_rows > 0) {
            // If user has a profile photo, delete the old photo file
            $oldPhotoPath = $checkPhotoResult->fetch_assoc()['profile_photo'];
            if (file_exists($oldPhotoPath)) {
                unlink($oldPhotoPath);
            }
        }

        // If everything is ok, try to upload file
        if (move_uploaded_file($_FILES["profile_photo"]["tmp_name"], $targetFile)) {
            // Insert user data into the database
            $sql = "INSERT INTO profile (user_id, name, password, email_id, phone_no, institution, designation, profile_photo) VALUES ('$username', '$name', '$password', '$email', '$mobilenumber', '$institution', '$designation', '$targetFile')";

            if ($conn->query($sql) === TRUE) {
                // Successful insertion
                $response = array('status' => 'success', 'message' => 'User registration successful.');
                echo json_encode($response);
            } else {
                // Error in database insertion
                $response = array('status' => 'error', 'message' => 'Error: ' . $conn->error);
                echo json_encode($response);
            }
        } else {
            $response = array('status' => 'error', 'message' => 'Sorry, there was an error uploading your file.');
            echo json_encode($response);
        }
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => 'error', 'message' => 'Invalid request method.');
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
