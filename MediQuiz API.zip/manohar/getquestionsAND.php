<?php
require_once('dp.php');

// Initialize an array to store the data
$data = array();
$response = array('status' => 'success', 'message' => 'Data retrieved successfully');

// Fetch data from 'questions' table
$questionsQuery = "SELECT * FROM questions";
$questionsResult = $conn->query($questionsQuery);

if ($questionsResult && $questionsResult->num_rows > 0) {
    while ($row = $questionsResult->fetch_assoc()) {
        $caseStudyId = (int)$row['id'];

        // Fetch corresponding data from 'sub_questions' based on 'id' in 'questions'
        $subQuestionsQuery = "SELECT * FROM sub_questions WHERE case_study_id = " . $row['id'];
        $subQuestionsResult = $conn->query($subQuestionsQuery);

        $subQuestions = array();
        if ($subQuestionsResult && $subQuestionsResult->num_rows > 0) {
            while ($subRow = $subQuestionsResult->fetch_assoc()) {
                $options = array(
                    array('option_id' => 1, 'option_desc' => $subRow['option_1']),
                    array('option_id' => 2, 'option_desc' => $subRow['option_2']),
                    array('option_id' => 3, 'option_desc' => $subRow['option_3']),
                    array('option_id' => 4, 'option_desc' => $subRow['option_4'])
                );

                $correctAnswer = (int)$subRow['correct_answer']; // Use the correct_answer directly

                $subQuestions[] = array(
                    'question_id' => (int)$subRow['question_id'], // Cast to int
                    'question' => $subRow['question'],
                    'options' => $options,
                    'correct_answer' => $correctAnswer
                );
            }
        }

        // Store the questions and related sub-questions in the data array
        $data[] = array(
            'id' => $caseStudyId,
            'Case_Study' => $row['Case_Study'],
            'photo' => $row['photo'],
            'sub_questions' => $subQuestions
        );
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'No data found';
}

// Add the data to the response
$response['data'] = $data;

// Convert the PHP array to JSON
$jsonData = json_encode($response);

// Output the JSON data
header('Content-Type: application/json');
echo $jsonData;

// Close the database connection
$conn->close();
?>
