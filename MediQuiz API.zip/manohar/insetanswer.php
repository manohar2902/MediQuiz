<?php

require_once('dp.php');

// Initialize response array
$response = array();

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data from form-data
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $case_study_id = isset($_POST['case_study_id']) ? intval($_POST['case_study_id']) : 0;

    // Check if the user already exists in the database
    $existingRowSql = "SELECT * FROM user_answers WHERE user_id = $user_id AND case_study_id = $case_study_id";
    $existingRowResult = $conn->query($existingRowSql);

    if ($existingRowResult->num_rows > 0) {
        // User already exists in the database
        $response['status'] = 'error';
        $response['message'] = 'User already exists in the database. No new data submitted.';
        echo json_encode($response);
        exit; // Stop further execution
    } else {
        // User does not exist, continue processing the submitted data
        // Initialize arrays to store data for batch insert and update
        $insertValues = [];
        $updateValues = [];

        // Loop through the answers
        for ($i = 1; $i <= 4; $i++) {
            // Get data for each question
            $question_id = isset($_POST["question_id_$i"]) ? intval($_POST["question_id_$i"]) : 0;
            $user_answer = isset($_POST["user_answer_$i"]) ? mysqli_real_escape_string($conn, $_POST["user_answer_$i"]) : '';

            // Fetch correct_answer for the given question_id and case_study_id from sub_questions
            $fetchCorrectAnswerQuery = "SELECT correct_answer FROM sub_questions WHERE question_id = $question_id AND case_study_id = $case_study_id";
            $correctAnswerResult = $conn->query($fetchCorrectAnswerQuery);

            if ($correctAnswerResult && $correctAnswerResult->num_rows > 0) {
                $row = $correctAnswerResult->fetch_assoc();
                $correct_answer = $row['correct_answer'];

                // Check if user's answer matches the correct_answer
                $Correct = ($user_answer === $correct_answer) ? 1 : 0;
                $Wrong = ($user_answer !== $correct_answer) ? 1 : 0;

                // Add values to the batch insert array
                $insertValues[] = "($user_id, $case_study_id, $question_id, '$user_answer', $Correct, $Wrong)";
            } else {
                $response['status'] = 'error';
                $response['message'] = 'No matching question found in sub_questions table for the given question_id and case_study_id.';
                echo json_encode($response);
                exit; // Stop further execution
            }
        }

        if (!empty($insertValues)) {
            // Prepare and execute the batch INSERT query
            $insertQuery = "INSERT INTO user_answers (user_id, case_study_id, question_id, user_answer, Correct, Wrong) VALUES " . implode(", ", $insertValues);

            if ($conn->query($insertQuery) === TRUE) {
                $response['status'] = 'success';
                $response['message'] = 'Records inserted successfully';
            } else {
                $response['status'] = 'error';
                $response['message'] = 'Error: ' . $insertQuery . '<br>' . $conn->error;
            }
        }

        if (!empty($updateValues)) {
            // Execute the batch UPDATE queries
            foreach ($updateValues as $updateQuery) {
                if ($conn->query($updateQuery) !== TRUE) {
                    $response['status'] = 'error';
                    $response['message'] = 'Error updating records: ' . $updateQuery . '<br>' . $conn->error;
                    echo json_encode($response);
                    exit; // Stop further execution
                }
            }
        }
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method. This endpoint only accepts POST requests.';
}

// Close the database connection
$conn->close();

// Send JSON response
header('Content-Type: application/json');
echo json_encode($response);

?>
