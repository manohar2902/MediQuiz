<?php
require_once('dp.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Perform query to select user_id and total_score where designation is 'student'
$select_query = "SELECT p.user_id, IFNULL(t.total_score, 0) AS total_score
                 FROM profile p
                 LEFT JOIN totalscore t ON p.user_id = t.user_id
                 WHERE p.designation = 'student'";
$result = $conn->query($select_query);

if ($result->num_rows > 0) {
    // Create an empty array to store the results
    $response = array();

    // Loop through the result set and add each row to the response array
    while ($row = $result->fetch_assoc()) {
        $response[] = array(
            'user_id' => $row['user_id'],
            'total_score' => $row['total_score']
        );
    }

    // Output the response array as JSON
    echo json_encode($response);
} else {
    // If no results found, output a JSON object with a message
    echo json_encode(array('message' => 'No results found'));
}

// Close the database connection
$conn->close();
?>
