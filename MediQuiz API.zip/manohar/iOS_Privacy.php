<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Privacy Policy - MediQuiz Pro</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        margin: 0;
        padding: 0;
        background-color: #f4f4f4;
      }
      .container {
        max-width: 800px;
        margin: 50px auto;
        padding: 20px;
        background: #fff;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      }
      h1,
      h2,
      h3 {
        color: #333;
      }
      p {
        color: #555;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <h1>Privacy Policy</h1>
      <p>
        Welcome to MediQuiz Pro, the ultimate digital companion for Pathology
        postgraduates specializing in Dermatopathology. This Privacy Policy
        outlines how we collect, use, and protect your personal information when
        you use our mobile app.
      </p>

      <h2>Interpretation and Definitions</h2>
      <h3>Interpretation</h3>
      <p>
        The words with initial capitalized letters have meanings defined under
        the following conditions. These definitions will have the same meaning
        whether they appear in singular or plural.
      </p>

      <h3>Definitions</h3>
      <ul>
        <li>
          <strong>Account:</strong> A unique account created for You to access
          our Service or parts of it.
        </li>
        <li>
          <strong>Affiliate:</strong> An entity controlling, controlled by, or
          under common control with a party.
        </li>
        <li><strong>Application:</strong> Refers to MediQuiz Pro.</li>
        <li>
          <strong>Company:</strong> Refers to MediQuiz Pro, the provider of the
          Dermatopathology self-assessment Service.
        </li>
        <li><strong>Country:</strong> Tamil Nadu, India.</li>
        <li>
          <strong>Device:</strong> Any device capable of accessing the Service, 
          including iPhone, iPad, and other smartphones or tablets.
        </li>
        <li>
          <strong>Personal Data:</strong> Any information relating to an
          identified or identifiable individual.
        </li>
        <li><strong>Service:</strong> The Application.</li>
        <li>
          <strong>Service Provider:</strong> Any person or entity processing
          data on behalf of the Company.
        </li>
        <li>
          <strong>Usage Data:</strong> Data collected automatically, generated
          by the use of the Service or from the Service infrastructure.
        </li>
        <li><strong>You:</strong> The individual accessing or using the
          Service.
        </li>
      </ul>

      <h2>Collecting and Using Your Personal Data</h2>
      <h3>Types of Data Collected</h3>

      <h4>Personal Data</h4>
      <p>
        While using our Service, we may ask You to provide certain personally
        identifiable information that can be used to contact or identify You.
        Personally identifiable information may include but is not limited to:
      </p>
      <ul>
        <li>Name</li>
        <li>Email address</li>
        <li>Institution or workplace</li>
        <li>Phone number</li>
      </ul>

      <h4>Usage Data</h4>
      <p>
        Usage Data is collected automatically when using the Service. It may
        include information such as:
      </p>
      <ul>
        <li>Your Device's IP address</li>
        <li>Browser type and version</li>
        <li>The pages of our Service you visit</li>
        <li>Time and date of your visit</li>
        <li>Time spent on those pages</li>
        <li>Unique device identifiers and other diagnostic data</li>
      </ul>
      <p>
        When accessing the Service via a mobile device, we may collect
        additional information such as device type, unique device ID, operating
        system version, and browser type.
      </p>

      <h4>Information Collected While Using the Application</h4>
      <p>
        While using our Application, with Your prior permission, we may collect:
      </p>
      <ul>
        <li>
          Images and other media from Your Device's camera or photo library for
          case scenario studies.
        </li>
      </ul>
      <p>
        You can enable or disable access to this information at any time through
        Your device settings.
      </p>

      <h2>Use of Your Personal Data</h2>
      <p>MediQuiz Pro may use the collected Personal Data for the following purposes:</p>
      <ul>
        <li><strong>To provide and maintain our Service:</strong> Including monitoring usage of our Service.</li>
        <li><strong>To manage Your Account:</strong> To identify You as a user and allow You to use the Service.</li>
        <li><strong>To contact You:</strong> Via email or notifications regarding app updates, important information, or customer service communications.</li>
        <li><strong>To provide You with news and information:</strong> About case scenarios and related services, unless You have opted out of receiving such information.</li>
        <li><strong>To manage Your requests:</strong> To respond to Your inquiries or technical issues.</li>
      </ul>

      <h2>Sharing Your Personal Data</h2>
      <ul>
        <li><strong>With Service Providers:</strong> To perform analysis or contact You.</li>
        <li><strong>For Business Transfers:</strong> During any mergers, acquisitions, or asset sales.</li>
        <li><strong>With Affiliates:</strong> With our parent companies, subsidiaries, or other affiliates.</li>
        <li><strong>With Business Partners:</strong> To offer products, services, or promotions.</li>
        <li><strong>With Other Users:</strong> When You publicly share information or interact with other users.</li>
        <li><strong>With Your Consent:</strong> For any other purposes with Your explicit consent.</li>
      </ul>

      <h2>Retention of Your Personal Data</h2>
      <p>
        MediQuiz Pro will retain Your Personal Data only for as long as necessary
        for the purposes outlined in this Privacy Policy, and to comply with
        legal obligations. Usage Data is retained for a shorter period, except
        when used for improving the functionality of our Service.
      </p>

      <h2>Transfer of Your Personal Data</h2>
      <p>
        Your information may be processed and stored on computers located
        outside of Your jurisdiction. Your consent to this Privacy Policy
        represents Your agreement to such transfers.
      </p>

      <h2>Security of Your Personal Data</h2>
      <p>
        We use commercially acceptable means to protect Your Personal Data, but
        no method of transmission or storage is 100% secure. While we strive to
        protect Your data, we cannot guarantee its absolute security.
      </p>

      <h2>Children's Privacy</h2>
      <p>
        MediQuiz Pro is not intended for individuals under 13 years of age. We do
        not knowingly collect data from children. If You are a parent or
        guardian and believe that Your child has provided us with personal data,
        please contact us.
      </p>

      <h2>Changes to This Privacy Policy</h2>
      <p>
        We may update this Privacy Policy from time to time. We will notify You
        of any changes by posting the new policy on this page and updating the
        "Last Updated" date. You are advised to review this Privacy Policy
        periodically.
      </p>

      <h2>Contact Us</h2>
      <p>
        If You have any questions about this Privacy Policy, You can contact us:
      </p>
      <ul>
        <li>By email: [Your email address]</li>
      </ul>

      <p>© 2024 MediQuiz Pro. All rights reserved.</p>
    </div>
  </body>
</html>
